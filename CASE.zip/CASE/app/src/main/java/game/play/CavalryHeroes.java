package game.play;

public class CavalryHeroes extends Heroes{
    public CavalryHeroes() {

        this.Type = Heroes.CAVALRY;
        this.skill = this.Cavalry_Skill/10;


    }

}
