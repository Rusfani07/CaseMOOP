package game.play;

public class ArcherHeroes extends Heroes {
    public  ArcherHeroes() {

        this.Type =Heroes.ARCHER;
        this.skill = this.Archer_Skill/10;
    }
}
