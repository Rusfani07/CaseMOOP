package game.play;

public class CatapultHeroes extends Heroes{
    public CatapultHeroes() {

        this.Type =Heroes.CATAPULT;
        this.skill = this.Catapult_Skill/10;
    }
}
