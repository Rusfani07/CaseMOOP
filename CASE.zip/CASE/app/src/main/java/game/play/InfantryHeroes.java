package game.play;

public class InfantryHeroes extends Heroes{
    public InfantryHeroes() {

        this.Type =Heroes.INFANTRY;
        this.skill = this.Infantry_Skill/10;
    }
}
